"use client";

import { useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { MapPin, Calendar, Clock, ArrowLeft, BookmarkCheck, BookmarkPlus, Share, Users, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/components/AuthContext";
import { OptimizedImage } from "@/components/OptimizedImage";
import { allCampaigns } from "@/lib/data";
import { useSavedItems } from "@/lib/saved-items";

export default function CampaignDetailPage() {
  const params = useParams();
  const id = (params.id as string) || "1";
  const router = useRouter();
  const { isLoggedIn, openLoginModal } = useAuth();
  const { isSaved, toggleSaved } = useSavedItems();

  const camp = useMemo(() => allCampaigns.find((item) => item.id === id) || allCampaigns[0], [id]);
  const saved = isSaved("campaign", camp.id);

  const handleApply = () => {
    if (!isLoggedIn) {
      openLoginModal();
      return;
    }

    toast.success("キャンペーンへエントリーしました");
  };

  const handleSave = () => {
    if (!isLoggedIn) {
      openLoginModal();
      return;
    }

    const savedAfterToggle = toggleSaved("campaign", camp.id);
    toast.success(savedAfterToggle ? "キャンペーンを保存しました" : "保存を解除しました");
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-white min-h-screen animate-slide-in-right">
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-pink-50 px-4 py-3 flex items-center justify-between">
        <button onClick={() => router.back()} className="p-2 -ml-2 text-gray-500 hover:bg-gray-50 rounded-full transition-colors"><ArrowLeft size={20} /></button>
        <span className="font-bold text-sm text-gray-800">キャンペーン詳細</span>
        <button className="p-2 -mr-2 text-gray-500 hover:bg-gray-50 rounded-full transition-colors"><Share size={18} /></button>
      </header>
      <div className="relative w-full h-56 overflow-hidden">
        <OptimizedImage src={camp.img} alt={camp.title} fill priority sizes="(max-width: 768px) 100vw, 640px" />
        <div className="absolute top-4 left-4 bg-pink-500 text-white text-[10px] font-bold px-3 py-1.5 rounded-full shadow-sm">{camp.tag}</div>
      </div>
      <div className="p-4 space-y-6 pb-28">
        <div>
          <h2 className="text-xl font-bold text-gray-800 leading-snug mb-3">{camp.title}</h2>
          <div className="flex items-center gap-2 text-sm text-gray-500 border-b border-gray-100 pb-4">
            <div className="w-6 h-6 rounded-full bg-pink-100 text-pink-500 flex items-center justify-center font-bold text-xs">C</div>
            <span>{camp.company}</span>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-2">
          <div className="bg-pink-50/50 p-3 rounded-xl flex items-start gap-3 border border-pink-100/50"><Calendar className="text-pink-500 mt-0.5" size={18} /><div><div className="text-xs text-gray-500 mb-0.5">開催日時</div><div className="text-sm font-bold text-gray-800">{camp.date}<br /><span className="text-xs font-normal text-gray-600">{camp.time}</span></div></div></div>
          <div className="bg-pink-50/50 p-3 rounded-xl flex items-start gap-3 border border-pink-100/50"><MapPin className="text-pink-500 mt-0.5" size={18} /><div><div className="text-xs text-gray-500 mb-0.5">開催場所</div><div className="text-sm font-bold text-gray-800">{camp.location}</div></div></div>
          <div className="bg-pink-50/50 p-3 rounded-xl flex items-start gap-3 border border-pink-100/50"><Users className="text-pink-500 mt-0.5" size={18} /><div><div className="text-xs text-gray-500 mb-0.5">対象・定員</div><div className="text-sm font-bold text-gray-800">{camp.target}<br /><span className="text-xs font-normal text-gray-600">定員: {camp.capacity}</span></div></div></div>
        </div>
        <div className="space-y-4">
          <h3 className="text-base font-bold text-gray-800 flex items-center gap-2 border-b border-pink-100 pb-2"><span className="w-1.5 h-4 bg-pink-400 rounded-full" />プログラム内容</h3>
          <div className="text-sm text-gray-600 leading-relaxed space-y-4">
            <p>{camp.description}</p>
            <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
              <h4 className="font-bold text-gray-800 mb-2 flex items-center gap-1.5 text-sm"><CheckCircle2 size={16} className="text-pink-500" /> 特典・メリット</h4>
              <ul className="list-disc list-inside text-xs space-y-1.5 ml-1 text-gray-600">
                <li>参加者全員にオリジナルグッズをプレゼント</li>
                <li>採用直結型の早期選考ルートへのご案内（希望者のみ）</li>
                <li>交通費の一部支給（遠方からの参加者のみ）</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="text-xs text-gray-400 flex items-center gap-4 border-t border-gray-100 pt-4">
          <div className="flex items-center gap-1"><Clock size={14} /> 受付中キャンペーン</div>
          <div className="flex items-center gap-1">ID: CAMP-{camp.id}</div>
        </div>
      </div>
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-pink-100 p-3 z-40 shadow-[0_-10px_20px_rgba(0,0,0,0.03)]">
        <div className="max-w-lg mx-auto flex gap-3">
          <button onClick={handleSave} className={`flex flex-col items-center justify-center w-16 shrink-0 rounded-xl border transition-colors active:scale-95 py-2 ${saved ? "bg-pink-500 border-pink-500 text-white" : "bg-pink-50 text-pink-500 border-pink-100 hover:bg-pink-100"}`}>{saved ? <BookmarkCheck size={20} className="mb-0.5" /> : <BookmarkPlus size={20} className="mb-0.5" />}<span className="text-[10px] font-bold">{saved ? "保存済み" : "保存"}</span></button>
          <button onClick={handleApply} className="flex-1 bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500 text-white font-bold rounded-xl flex justify-center items-center gap-2 shadow-sm hover:shadow-md transition-all active:scale-[0.98] py-3">エントリーする</button>
        </div>
      </div>
    </div>
  );
}
